# Git Cheatsheet for DevOps Work

## Daily flow
| Goal | Command |
|---|---|
| New branch | `git checkout -b feature/PROJ-123-short-name` |
| See changes | `git status`, `git diff` |
| Stage files | `git add path/to/file` |
| Commit | `git commit -m "PROJ-123: add nginx config"` |
| Push first time | `git push -u origin <branch>` |
| Update from main | `git fetch origin && git rebase origin/main` |

## Conventional Commit prefixes
`feat:` `fix:` `chore:` `ci:` `docs:` `refactor:` `test:`

## Merge and conflicts
```
git merge <branch>
# edit conflicted files, remove markers
git add <file>
git commit
git merge --abort      # give up and go back
```
Rebase: `git rebase main`, fix, `git add`, `git rebase --continue` (or `--abort`).

## Undo safely
| Situation | Command |
|---|---|
| Undo a pushed commit | `git revert <hash>` |
| Undo a pushed merge | `git revert -m 1 <merge-hash>` |
| Undo last local commit, keep changes staged | `git reset --soft HEAD~1` |
| Discard local edits to a file | `git restore <file>` |
| Unstage a file | `git restore --staged <file>` |

Never use `reset --hard` or force-push on shared branches like `main`.

## Inspect history
```
git log --oneline --graph --all
git show <hash>
git blame <file>
git reflog          # recovery lifeline for "lost" commits
```

## Tags and releases
```
git tag v1.4.2
git push origin v1.4.2
```

## Stash
```
git stash
git stash pop
```
