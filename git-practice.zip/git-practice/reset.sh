#!/usr/bin/env bash
# Deletes the practice repo so you can run setup.sh again.
rm -rf practice-repo
echo "practice-repo removed. Run: bash setup.sh"
