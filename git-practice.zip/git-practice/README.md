# Git Practice Kit (DevOps workflow)

Practice: branch -> commit -> merge conflict -> resolve -> revert.
Requires only Git (Linux, macOS, or Git Bash on Windows).

## Start
```
cd git-practice
bash setup.sh
cd practice-repo
```
The script creates a repo where `main` and `feature/PROJ-1-change-port` have both changed the same line of `app.conf`.

## Step 1: Look around
```
git log --oneline --graph --all
git branch
cat app.conf
```

## Step 2: Merge and hit the conflict
```
git merge feature/PROJ-1-change-port
```
Git reports a CONFLICT. Run `git status` and open `app.conf`.

## Step 3: Resolve it
Edit `app.conf`, keep the value you want (e.g. `port=9090`), and delete the three marker lines
(`<<<<<<<`, `=======`, `>>>>>>>`). Then:
```
git add app.conf
git commit -m "Merge PROJ-1: resolve port conflict"
```

## Step 4: Revert the merge
```
git log --oneline
git revert -m 1 <merge-commit-hash>
cat app.conf
```
The change is undone, history is kept, and a new revert commit appears.

## Bonus challenges
1. Run `bash ../reset.sh && bash ../setup.sh`, then repeat using `git rebase main` from the feature branch instead of merge. Resolve with `git add` + `git rebase --continue`.
2. Make a commit, then undo it (not pushed) with `git reset --soft HEAD~1`.
3. Tag a release: `git tag v1.0.0`, then list tags with `git tag`.
4. Write 3 commits using Conventional Commit style (`feat:`, `fix:`, `chore:`).
5. Use `git stash` to save half-done work, switch branches, then `git stash pop`.

## Start over any time
```
cd ..
bash reset.sh
bash setup.sh
```
