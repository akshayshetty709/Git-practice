#!/usr/bin/env bash
# Creates ./practice-repo with diverged branches that conflict on merge.
set -e

if [ -d practice-repo ]; then
  echo "practice-repo already exists. Run: bash reset.sh"
  exit 1
fi

mkdir practice-repo
cd practice-repo
git init -q -b main
git config user.name "Practice User"
git config user.email "practice@example.com"

echo "port=8080" > app.conf
git add app.conf
git commit -q -m "chore: add initial app config"

git checkout -q -b feature/PROJ-1-change-port
echo "port=9090" > app.conf
git commit -q -am "PROJ-1: change port to 9090"

git checkout -q main
echo "port=7070" > app.conf
git commit -q -am "PROJ-2: change port to 7070"

echo
echo "Ready. You are on 'main' inside practice-repo."
echo "Next: git merge feature/PROJ-1-change-port   (expect a conflict)"
echo "See README.md for the steps."
